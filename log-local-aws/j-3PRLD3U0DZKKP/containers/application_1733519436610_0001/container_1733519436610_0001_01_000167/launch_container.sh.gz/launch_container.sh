#!/bin/bash

set -o pipefail -e
export PRELAUNCH_OUT="/var/log/hadoop-yarn/containers/application_1733519436610_0001/container_1733519436610_0001_01_000167/prelaunch.out"
exec >"${PRELAUNCH_OUT}"
export PRELAUNCH_ERR="/var/log/hadoop-yarn/containers/application_1733519436610_0001/container_1733519436610_0001_01_000167/prelaunch.err"
exec 2>"${PRELAUNCH_ERR}"
echo "Setting up env variables"
export JAVA_HOME=${JAVA_HOME:-"/etc/alternatives/jre"}
export HADOOP_COMMON_HOME=${HADOOP_COMMON_HOME:-"/usr/lib/hadoop"}
export HADOOP_HDFS_HOME=${HADOOP_HDFS_HOME:-"/usr/lib/hadoop-hdfs"}
export HADOOP_CONF_DIR=${HADOOP_CONF_DIR:-"/etc/hadoop/conf"}
export HADOOP_YARN_HOME=${HADOOP_YARN_HOME:-"/usr/lib/hadoop-yarn"}
export PATH=${PATH:-"/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin"}
export HADOOP_TOKEN_FILE_LOCATION="/mnt/yarn/usercache/hadoop/appcache/application_1733519436610_0001/container_1733519436610_0001_01_000167/container_tokens"
export CONTAINER_ID="container_1733519436610_0001_01_000167"
export NM_PORT="8041"
export NM_HOST="ip-172-31-39-29.ec2.internal"
export NM_HTTP_PORT="8042"
export LOCAL_DIRS="/mnt/yarn/usercache/hadoop/appcache/application_1733519436610_0001"
export LOCAL_USER_DIRS="/mnt/yarn/usercache/hadoop/"
export LOG_DIRS="/var/log/hadoop-yarn/containers/application_1733519436610_0001/container_1733519436610_0001_01_000167"
export USER="hadoop"
export LOGNAME="hadoop"
export HOME="/home/"
export PWD="/mnt/yarn/usercache/hadoop/appcache/application_1733519436610_0001/container_1733519436610_0001_01_000167"
export LOCALIZATION_COUNTERS="0,261265,0,2,5"
export JVM_PID="$$"
export NM_AUX_SERVICE_mapreduce_shuffle="AAA0+gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="
export STDOUT_LOGFILE_ENV="/var/log/hadoop-yarn/containers/application_1733519436610_0001/container_1733519436610_0001_01_000167/stdout"
export SHELL="/bin/bash"
export HADOOP_ROOT_LOGGER="INFO,console"
export HADOOP_MAPRED_HOME="/usr/lib/hadoop-mapreduce"
export CLASSPATH="$PWD:$HADOOP_CONF_DIR:$HADOOP_COMMON_HOME/*:$HADOOP_COMMON_HOME/lib/*:$HADOOP_HDFS_HOME/*:$HADOOP_HDFS_HOME/lib/*:$HADOOP_MAPRED_HOME/*:$HADOOP_MAPRED_HOME/lib/*:$HADOOP_YARN_HOME/*:$HADOOP_YARN_HOME/lib/*:/usr/lib/hadoop-lzo/lib/*:/usr/share/aws/emr/emrfs/conf:/usr/share/aws/emr/emrfs/lib/*:/usr/share/aws/emr/emrfs/auxlib/*:/usr/share/aws/emr/lib/*:/usr/share/aws/emr/ddb/lib/emr-ddb-hadoop.jar:/usr/share/aws/emr/goodies/lib/emr-hadoop-goodies.jar:/usr/share/aws/emr/kinesis/lib/emr-kinesis-hadoop.jar:/usr/share/aws/emr/cloudwatch-sink/lib/*:/usr/share/aws/aws-java-sdk/*:$HADOOP_MAPRED_HOME/share/hadoop/mapreduce/*:$HADOOP_MAPRED_HOME/share/hadoop/mapreduce/lib/*:/usr/lib/hadoop-lzo/lib/*:/usr/share/aws/emr/emrfs/conf:/usr/share/aws/emr/emrfs/lib/*:/usr/share/aws/emr/emrfs/auxlib/*:/usr/share/aws/emr/lib/*:/usr/share/aws/emr/ddb/lib/emr-ddb-hadoop.jar:/usr/share/aws/emr/goodies/lib/emr-hadoop-goodies.jar:/usr/share/aws/emr/kinesis/lib/emr-kinesis-hadoop.jar:/usr/share/aws/emr/cloudwatch-sink/lib/*:/usr/share/aws/aws-java-sdk/*:job.jar/*:job.jar/classes/:job.jar/lib/*:$PWD/*"
export LD_LIBRARY_PATH="$PWD:/usr/lib/hadoop/lib/native:/usr/lib/hadoop-lzo/lib/native"
export STDERR_LOGFILE_ENV="/var/log/hadoop-yarn/containers/application_1733519436610_0001/container_1733519436610_0001_01_000167/stderr"
export HADOOP_CLIENT_OPTS=""
export MALLOC_ARENA_MAX="4"
echo "Setting up job resources"
ln -sf -- "/mnt/yarn/usercache/hadoop/appcache/application_1733519436610_0001/filecache/11/job.xml" "job.xml"
ln -sf -- "/mnt/yarn/usercache/hadoop/appcache/application_1733519436610_0001/filecache/10/job.jar" "job.jar"
echo "Copying debugging information"
# Creating copy of launch script
cp "launch_container.sh" "/var/log/hadoop-yarn/containers/application_1733519436610_0001/container_1733519436610_0001_01_000167/launch_container.sh"
chmod 640 "/var/log/hadoop-yarn/containers/application_1733519436610_0001/container_1733519436610_0001_01_000167/launch_container.sh"
# Determining directory contents
echo "ls -l:" 1>"/var/log/hadoop-yarn/containers/application_1733519436610_0001/container_1733519436610_0001_01_000167/directory.info"
ls -l 1>>"/var/log/hadoop-yarn/containers/application_1733519436610_0001/container_1733519436610_0001_01_000167/directory.info"
echo "find -L . -maxdepth 5 -ls:" 1>>"/var/log/hadoop-yarn/containers/application_1733519436610_0001/container_1733519436610_0001_01_000167/directory.info"
find -L . -maxdepth 5 -ls 1>>"/var/log/hadoop-yarn/containers/application_1733519436610_0001/container_1733519436610_0001_01_000167/directory.info"
echo "broken symlinks(find -L . -maxdepth 5 -type l -ls):" 1>>"/var/log/hadoop-yarn/containers/application_1733519436610_0001/container_1733519436610_0001_01_000167/directory.info"
find -L . -maxdepth 5 -type l -ls 1>>"/var/log/hadoop-yarn/containers/application_1733519436610_0001/container_1733519436610_0001_01_000167/directory.info"
echo "Launching container"
exec /bin/bash -c "$JAVA_HOME/bin/java -Djava.net.preferIPv4Stack=true -Dhadoop.metrics.log.level=WARN  -Xmx2458m -Djava.io.tmpdir=$PWD/tmp -Dlog4j.configuration=container-log4j.properties -Dyarn.app.container.log.dir=/var/log/hadoop-yarn/containers/application_1733519436610_0001/container_1733519436610_0001_01_000167 -Dyarn.app.container.log.filesize=0 -Dhadoop.root.logger=INFO,CLA -Dhadoop.root.logfile=syslog -Dyarn.app.mapreduce.shuffle.logger=INFO,shuffleCLA -Dyarn.app.mapreduce.shuffle.logfile=syslog.shuffle -Dyarn.app.mapreduce.shuffle.log.filesize=0 -Dyarn.app.mapreduce.shuffle.log.backups=0 org.apache.hadoop.mapred.YarnChild 172.31.35.42 37563 attempt_1733519436610_0001_r_000161_0 167 1>/var/log/hadoop-yarn/containers/application_1733519436610_0001/container_1733519436610_0001_01_000167/stdout 2>/var/log/hadoop-yarn/containers/application_1733519436610_0001/container_1733519436610_0001_01_000167/stderr "
